﻿using Docear4Word;

using NUnit.Framework;

namespace docear4word.UnitTest.StyleTests
{
	[TestFixture]
	public class StyleTests
	{
		[Test]
		public void TestBibtexInstitutionIsMapped()
		{
		}
	}
}